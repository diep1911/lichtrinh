# Ứng dụng iPhone: gói thiết kế và đóng gói

Không tạo được tệp IPA trực tiếp ở đây: IPA cần macOS, Xcode và chứng chỉ ký của Apple Developer. Gói này chứa mã nguồn thiết kế hoàn chỉnh, chạy ngay dưới dạng ứng dụng web cài được (PWA) và sẵn cấu hình để đóng thành IPA.

## Cấu trúc

```
.
├── README.md
├── capacitor.config.json      appId và appName là giá trị tạm, hãy đổi trước khi phát hành
└── www/
    ├── index.html             toàn bộ giao diện, CSS và JS trong một tệp
    ├── manifest.webmanifest   khai báo cài đặt, hiển thị dọc, toàn màn hình
    ├── sw.js                  cache để mở lại không cần mạng
    └── icons/                 icon-180.png, icon-192.png, icon-512.png
```

## Cách A: cài thẳng lên iPhone (không cần Mac)

1. Đưa nguyên thư mục `www/` lên một máy chủ HTTPS bất kỳ.
2. Mở địa chỉ đó bằng Safari trên iPhone.
3. Bấm Chia sẻ, chọn Thêm vào Màn hình chính.

## Cách B: đóng thành IPA (cần Mac có Xcode)

```
npm init -y
npm i @capacitor/core @capacitor/ios
npm i -D @capacitor/cli
npx cap add ios
npx cap sync ios
npx cap open ios
```

Trong Xcode: chọn Team ký, đổi Bundle Identifier cho khớp `appId`, rồi Product, Archive để xuất IPA hoặc đẩy lên App Store Connect.

## Thiết kế

- Màu: nền `#F3F5F9`, bề mặt `#FFFFFF`, chữ `#12151C`, màu nhấn duy nhất `#3556E8`; có chế độ tối tự động.
- Chữ: font hệ thống của iPhone (`-apple-system`), tiêu đề lớn 34px, thân 16px.
- Khoảng cách: lưới 4px, lề màn hình 20px, bo góc thẻ 20px.
- Chuyển cảnh: đổi tab trượt nhẹ kèm mờ dần; mở chi tiết trượt từ phải, màn hình dưới lùi và tối nhẹ; bảng tạo mới trượt từ dưới lên. Mọi nút nhấn đều co nhẹ khi chạm. Tôn trọng cài đặt giảm chuyển động.
- Chữ trên giao diện chỉ là nhãn cấu trúc (Trang chủ, Nội dung, Khác, Thẻ 1, Mô tả ngắn của thẻ...). Thay bằng nội dung thật khi có.
